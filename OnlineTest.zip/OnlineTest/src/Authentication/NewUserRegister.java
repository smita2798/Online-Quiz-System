package Authentication;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class NewUserRegister {
    public int register() {
        String Ans = getInput("Create UserName:");
        String fileName = "UserName.txt";
        String str = Ans;
        appendStrToFile(fileName, str);

        String Ans1 = getInput("Create Password:");
        String fileName1 = "Password.txt";
        String str1 = Ans1;
        appendStrToFile(fileName1, str1);
        return 1;

    }

    static String getInput(String prompt) {
        System.out.print(prompt);
        Scanner console = new Scanner(System.in);
        return console.nextLine();
    }

    public static void appendStrToFile(String fileName,
                                       String str) {
        try {

            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(
                    new FileWriter(fileName, true));
            out.write(str);
            out.newLine();
            out.close();
        } catch (IOException e) {
            System.out.println("exception occoured" + e);
        }

    }
}
