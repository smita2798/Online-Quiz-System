package write;
import java.io.*;
public class write1 {
    public static void appendStrToFile(String fileName,
                                       String str)
    {
        try {

            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(
                    new FileWriter(fileName, true));
            out.write(str);
            out.close();
        }
        catch (IOException e) {
            System.out.println("exception occoured" + e);
        }
    }
    public void write_answer() {
        {
            String fileName = "C:Answer.txt";
            String str = "Right Answer\n";
            appendStrToFile(fileName, str);
        }
    }
}

