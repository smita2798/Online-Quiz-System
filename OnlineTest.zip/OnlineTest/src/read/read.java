package read;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class read {
    public void Read(int Que) {
        try {
            switch (Que) {
                case 1:
                    {
                    File myObj = new File("C:Ques1.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 2:
                {
                    File myObj = new File("C:Ques2.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 3:
                {
                    File myObj = new File("C:Ques3.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 4:
                {
                    File myObj = new File("C:Ques4.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 5:
                {
                    File myObj = new File("C:Ques5.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 6:
                {
                    File myObj = new File("C:Ques6.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 7:
                {
                    File myObj = new File("C:Ques7.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 8:
                {
                    File myObj = new File("C:Ques8.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 9:
                {
                    File myObj = new File("C:Ques9.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                case 10:
                {
                    File myObj = new File("C:Ques10.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        System.out.println(data);
                    }
                    myReader.close();
                }
                break;
                default:
                    System.out.println("Question does not exists.");

            }

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}

