package test;
import read.*;
import write.*;
import java.util.Scanner;
import Authentication.*;
public class Main {
    static String getInput (String prompt){
        System.out.print(prompt);
        Scanner console = new Scanner(System.in);
        return console.nextLine();
    }
    public static void main(String[] args) {
         String opt = getInput("1.Register New User\n" +
                "2.Login Existing User\n");
        switch (opt) {
            case "1": {
                NewUserRegister obje = new NewUserRegister();
                obje.register();
            }
            break;
            case "2": {
                Login objec = new Login();
                int y = objec.log();
                if (y == 1) {
                    String str = "CBBDADBBDA";
                    char[] ch = str.toCharArray();
                    for (int i = 0; i < str.length(); i++) {

                        read obj = new read();
                        obj.Read(i + 1);
                        String Ans = getInput("Please choose one option from A,B,C or D : ");
                        char c = Ans.charAt(0);
                        if (c == ch[i]) {
                            write1 obj2 = new write1();
                            obj2.write_answer();
                        } else {
                            write2 obj3 = new write2();
                            obj3.write_answer();
                        }
                    }
                    Ans_read obj = new Ans_read();
                    obj.Read();

                } else {
                    System.out.println("Fail");
                }
            }
            break;
        }

    }
}
