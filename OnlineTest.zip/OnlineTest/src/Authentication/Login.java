package Authentication;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Login {
    public int log() {
        try {
            String Ans = getInput("Enter UserName:");
            File myObj = new File("C:UserName.txt");
            Scanner myReader = new Scanner(myObj);
            int count = 0;
            while (myReader.hasNextLine()) {
                count = count+1;
                String data = myReader.nextLine();
                int res = data.compareTo(Ans);
                if (res==0){
                    try {
                        String Ans1 = getInput("Enter Password:");
                        File myObj1 = new File("C:Password.txt");
                        Scanner myReader1 = new Scanner(myObj1);
                        int count1 = 0;
                        while (myReader1.hasNextLine()) {
                            count1 = count1 +1;
                            String data1 = myReader1.nextLine();
                            int res1 = data1.compareTo(Ans1);
                            if(res1==0 && count==count1 ){
                                return 1;
                            }else {
                                if(myReader1.hasNextLine()== false){
                                    System.out.println("Wrong Password");
                                    return 0;
                                }


                            }

                        }
                        myReader1.close();

                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                }else {
                    if(myReader.hasNextLine()== false){
                        System.out.println("Wrong UserName");
                    }
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return 0;
    }
    static String getInput(String prompt) {
        System.out.print(prompt);
        Scanner console = new Scanner(System.in);
        return console.nextLine();
    }
}
